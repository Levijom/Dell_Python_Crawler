from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import xlsxwriter
import argparse
import re


def MakeCell(row, column):
    # "This prints a passed string into this function"
    return chr(ord("A") + column) + str(row + 1)


# Getting Correct Command Line requirements
# Usage: python QuoteCrawler SOURCE.TXT DESTINATION.XLSX

parser = argparse.ArgumentParser()
parser.add_argument("sourceFile", type=str, help="Source File (txt format)")
parser.add_argument("destFile", type=str, help="Destination file (xlsx format)")
parser.add_argument(
    "--customerready", help="Remove internal information", action="store_true"
)
args = parser.parse_args()

try:
    sourceFile = open(args.sourceFile, "rt")

except:
    print("Error opening file " + args.sourceFile)
    quit()

quote_list = sourceFile.readlines()  # List of Quotes
sourceFile.close()

options = webdriver.ChromeOptions()
options.add_experimental_option("excludeSwitches", ["enable-logging"])
driver = webdriver.Chrome(options=options)

workbook = xlsxwriter.Workbook(args.destFile)  # Create Excel File

standard_format = workbook.add_format()
money_format = workbook.add_format({"num_format": "$#,##0"})
percentage_format = workbook.add_format({"num_format": "0.00%"})
modifier_format = workbook.add_format({"num_format": "0.00"})
number_format = workbook.add_format({"num_format": "0"})
processor_format = workbook.add_format({"bold": 0})
processor_format.set_bg_color("#FFFF00")  # yellow
memory_format = workbook.add_format({"bold": 0})
memory_format.set_bg_color("#CCFFFF")  # lightblue
bold = workbook.add_format({"bold": 1})

worksheet = workbook.add_worksheet("Main")  # Create Main Sheet
worksheet.write("A1", "Quote #", bold)
worksheet.set_column(0, 0, 15)  # Width of column A set to 14.
worksheet.write("B1", "Config ID", bold)
worksheet.set_column(1, 1, 10)  # Width of column B set to 10.
worksheet.write("C1", "List Price", bold)
worksheet.write("D1", "Sale Price", bold)
worksheet.write("E1", "Freight Price", bold)
worksheet.write("F1", "DOL%", bold)
worksheet.write("G1", "Modifier", bold)
# worksheet.write('G1', 'Quantity', bold)
worksheet.write("H1", "Quote Name", bold)
worksheet.write("I1", "Shipping Adress", bold)


comparisonsheet = workbook.add_worksheet("Comparison")  # ComparisonSheet
comparisonsheet.set_column(0, len(quote_list), 50)

intelsheet = workbook.add_worksheet("Intel Processors")
intelsheet.write("A1", "Quote #", bold)
intelsheet.set_column(0, 0, 16)  # Width of column A set to 16.
intelsheet.write("B1", "Proc quantity", bold)
intelsheet.write("C1", "Intel Processor", bold)
intelsheet.set_column(2, 2, 50)  # Width of column B set to 50.

intelsheetrow = 1

quote = 0

for quoteNumberFromList in quote_list:
    quote += 1
    quoteNumberFromList = quoteNumberFromList.split()[0].strip("US-").replace("/", ".")

    url = (
        "https://sales.dell.com/#/quote/details/QuoteNumber/"
        + quoteNumberFromList.strip("\n")
    )

    try:
        print("Trying quote #" + quoteNumberFromList.strip("\n"))

        driver.get(url)
        driver.refresh()

        quotenumber = WebDriverWait(driver, 90).until(
            EC.presence_of_element_located((By.ID, ("quoteNumber")))
        )
        quotenumberversion = WebDriverWait(driver, 60).until(
            EC.presence_of_element_located((By.ID, ("quoteDetail_versionToggle")))
        )
        solutionnumber = WebDriverWait(driver, 60).until(
            EC.presence_of_element_located((By.ID, ("quoteDetail_items_header_s")))
        )
        TotalListPrice = WebDriverWait(driver, 60).until(
            EC.presence_of_element_located((By.ID, ("quoteDetail_summary_listPrice")))
        )
        TotalSellingPrice = WebDriverWait(driver, 60).until(
            EC.presence_of_element_located(
                (By.ID, ("quoteDetail_summary_sellingPrice"))
            )
        )
        TotalShippingPrice = WebDriverWait(driver, 60).until(
            EC.presence_of_element_located(
                (By.ID, ("quoteDetail_summary_shippingPriceAmount"))
            )
        )
        TotalDiscount = WebDriverWait(driver, 60).until(
            EC.presence_of_element_located(
                (By.ID, ("quoteDetail_summary_discountPercent"))
            )
        )
        OverallModifier = WebDriverWait(driver, 60).until(
            EC.presence_of_element_located(
                (By.ID, ("quoteDetail_GI_with_pricing_modifier"))
            )
        )
        # new ones
        shippingAdress = WebDriverWait(driver, 60).until(
            EC.presence_of_element_located(
                (By.ID, ("quoteDetail_GI_shippingAddress_0"))
            )
        )
        quoteName = WebDriverWait(driver, 60).until(
            EC.presence_of_element_located((By.ID, ("quoteDetail_title")))
        )

        i = 0  # SubItems
        quoteNumberWithVersion = (
            quotenumber.text + "." + str(quotenumberversion.text.split()[1])
        )
        worksheet.write(quote, 0, quoteNumberWithVersion)  # Quote Number
        worksheet.write(quote, 1, str(solutionnumber.text.split()[2]))  # Config ID
        worksheet.write_number(
            quote,
            2,
            float(TotalListPrice.text.strip("$").replace(",", "")),
            money_format,
        )  # List Price
        worksheet.write_number(
            quote,
            3,
            float(TotalSellingPrice.text.strip("$").replace(",", "")),
            money_format,
        )  # Sale Price
        worksheet.write_number(
            quote,
            4,
            float(TotalShippingPrice.text.strip("$").replace(",", "")),
            money_format,
        )  # Freight Price
        worksheet.write_number(
            quote,
            5,
            float(TotalDiscount.text.split()[2].strip("%")) / 100.0,
            percentage_format,
        )  # DOL%
        worksheet.write_number(
            quote, 6, float(OverallModifier.text), modifier_format
        )  # Modifier
        worksheet.write(quote, 7, quoteName.text)  # Quote Name
        worksheet.write(quote, 8, shippingAdress.text)  # Quote Name

        quotesheet = workbook.add_worksheet(
            quoteNumberWithVersion
        )  # Create one Sheet per quote
        worksheet.write_url(
            MakeCell(quote, 0), "internal:" + quoteNumberWithVersion + "!A1"
        )  # adds the URL to the right tab

        #        quotesheet.write('A1', 'RETURN TO MAIN',bold)
        quotesheet.write_url(
            "C1", "internal:Main!" + MakeCell(quote, 0), string="RETURN TO MAIN"
        )  # return button
        quotesheet.write("D1", "Quote #" + quoteNumberWithVersion, bold)
        quotesheet.write("A2", "ID", bold)
        quotesheet.set_column(0, 0, 3.5)  # ID with width of 3.5
        if args.customerready == False:
            quotesheet.write("B2", "UnitListPrice", bold)
            quotesheet.write("C2", "UnitSalePrice", bold)
            quotesheet.write("D2", "Quantity", bold)
            quotesheet.write("E2", "DOL%", bold)
            quotesheet.write("F2", "Modifier", bold)
            quotesheet.write("G2", "Configuration", bold)
            quotesheet.set_column(6, 6, 30)
            quotesheet.set_column(7, 7, 50)
        else:
            quotesheet.write("B2", "Quantity", bold)
            quotesheet.set_column(2, 2, 30)
            quotesheet.set_column(3, 3, 50)

        comparisonsheet.write(
            0, quote - 1, quoteNumberWithVersion, bold
        )  # Quote Number
        comparisonsheet_row = 1

        quotesheetrow = 2
    except:
        print("Error getting quote #" + quoteNumberFromList.strip("\n"))
        continue

    while True:  # Checking how many items are in a quote
        SubItem = "toggleMoreLess_0_" + str(i)
        try:
            print("Trying " + SubItem)
            timetowait = 60 if i == 0 else 1
            SeeMore = WebDriverWait(driver, timetowait).until(
                EC.presence_of_element_located((By.ID, (SubItem)))
            )
            SeeMore = WebDriverWait(driver, timetowait).until(
                EC.element_to_be_clickable((By.ID, (SubItem)))
            )
            SeeMore.click()
            # Found that subGroup
            print("Found " + SubItem)
            print("-------------")
            print("SubItem " + str(i))

            ListPrice = WebDriverWait(driver, 60).until(
                EC.presence_of_element_located(
                    (By.ID, ("quoteDetail_LI_PI_unitPrice_0_" + str(i)))
                )
            )
            SellingPrice = WebDriverWait(driver, 60).until(
                EC.presence_of_element_located(
                    (By.ID, ("quoteDetail_LI_PI_unitSellingPrice_OC_0_" + str(i)))
                )
            )
            Modifier = WebDriverWait(driver, 60).until(
                EC.presence_of_element_located(
                    (By.ID, ("quoteDetail_LI_pricingModifier_0_" + str(i)))
                )
            )
            DOL = WebDriverWait(driver, 60).until(
                EC.presence_of_element_located(
                    (By.ID, ("quoteDetail_LI_PI_dolPercentage_0_" + str(i)))
                )
            )
            configuration = WebDriverWait(driver, 60).until(
                EC.presence_of_element_located(
                    (By.ID, ("lineitem_config_block_0_" + str(i)))
                )
            )
            # new ones
            quantity = WebDriverWait(driver, 60).until(
                EC.presence_of_element_located(
                    (By.ID, ("quoteDetail_LI_quantity_0_" + str(i)))
                )
            )

            quotesheet.write_number(quotesheetrow, 0, i)
            if args.customerready == False:  # Adds internal information
                quotesheet.write_number(
                    quotesheetrow,
                    1,
                    float(ListPrice.text.strip("$").replace(",", "")),
                    money_format,
                )  # List Price
                quotesheet.write_number(
                    quotesheetrow,
                    2,
                    float(SellingPrice.text.strip("$").replace(",", "")),
                    money_format,
                )  # Selling Price
                quotesheet.write_number(
                    quotesheetrow, 3, int(quantity.text.replace(",", "")), number_format
                )  # Quantity
                quotesheet.write_number(
                    quotesheetrow,
                    4,
                    float(DOL.text.strip("%")) / 100.0,
                    percentage_format,
                )  # DOL%
                quotesheet.write_number(
                    quotesheetrow, 5, float(Modifier.text), modifier_format
                )  # Modifier
            else:
                quotesheet.write_number(
                    quotesheetrow, 1, int(quantity.text.replace(",", "")), number_format
                )  # Quantity

            aux = True
            for line in configuration.text.splitlines():
                if args.customerready == False:
                    columnToWrite = 6 if aux else 7
                else:
                    columnToWrite = 2 if aux else 3

                quotesheet.write(quotesheetrow, columnToWrite, line)
                if not aux:
                    formattouse = standard_format
                    if "Xeon" in line:
                        formattouse = processor_format
                        intelsheet.write(
                            intelsheetrow, 0, quoteNumberWithVersion, bold
                        )  # also write on the Intel Sheet
                        intelsheet.write_number(
                            intelsheetrow,
                            1,
                            int(quantity.text.replace(",", "")),
                            number_format,
                        )
                        intelsheet.write(intelsheetrow, 2, line)
                        intelsheetrow += 1
                    if (
                        "RDIMM" in line
                        or "rNDC" in line
                        or "SSD" in line
                        or "NVM" in line
                        or "15K" in line
                    ):
                        formattouse = memory_format
                    comparisonsheet.write(
                        comparisonsheet_row, quote - 1, line, formattouse
                    )
                    quotesheetrow += 1
                    comparisonsheet_row += 1
                aux = not aux

            quotesheetrow += 1
            i += 1  # go to the next item
        except:
            break

workbook.close()
driver.close()

# TO do an internal URL: worksheet.write_url('A1',  'internal:testao!A1')